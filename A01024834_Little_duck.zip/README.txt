Comando para generar/actualizar los archivos del Scanner y el Parser:
    C:/.../ driver> antlr4 -v 4.13.0 -Dlanguage=Python3 little_duck.g4

Comando para compilar un archivo     
    python Driver/Driver.py "nombre del archivo"
    ej.  
    python Driver/Driver.py test/test1.txt

Todas las pruebas se encuentran en la carpeta "test":

    test1: test de programa 
    test2: test de variable y asignación 
    test3: test de print
    test4: test de Func  #no se implemento 
    test5: test de condicional 
    test6: test de ciclo 
    testF: test de integración 
 
